﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CVA.NF.Import.MODEL
{
    public enum ImportResultEnum
    {
        Success,
        GeneralError,
        ImportedWithError
    }
}
