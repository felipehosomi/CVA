﻿namespace CVA.AddOn.Common.UI
{
    public class DocumentIDs
    {
        public static string MainUsage = "1720002171";
        public static string ItemMatrix = "38";
    }

    public class ItemMatrixIDs
    {
        public static string ItemCode = "1";
        public static string ItemName = "3";
        public static string Usage = "2011";
    }
}
