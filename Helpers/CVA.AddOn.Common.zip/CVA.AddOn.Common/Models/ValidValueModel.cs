﻿namespace CVA.AddOn.Common.Models
{
    public class ValidValueModel
    {
        public string Value { get; set; }
        public string Description { get; set; }
    }
}
