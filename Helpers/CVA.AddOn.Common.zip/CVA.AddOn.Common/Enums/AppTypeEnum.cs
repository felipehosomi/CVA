﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CVA.AddOn.Common.Enums
{
    public enum AppTypeEnum
    {
        SBO,
        Generic
    }
}
