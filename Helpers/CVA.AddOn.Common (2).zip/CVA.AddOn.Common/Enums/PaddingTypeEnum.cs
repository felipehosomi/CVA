﻿namespace CVA.AddOn.Common.Enums
{
    public enum PaddingTypeEnum
    {
        NotSet,
        Right,
        Left,
        None
    }
}
