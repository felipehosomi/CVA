﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CVA.AddOn.Common.Models
{
    public class TableModel
    {
        public string Table { get; set; }
        public string DescTable { get; set; }
        public bool Create { get; set; }
    }
}
