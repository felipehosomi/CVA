﻿using CVA.AddOn.Common.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CVA.AddOn.Common.Models
{
    public class FileAttributeModel
    {
        public string Value { get; set; }

        public int Position { get; set; }
    }
}
