﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CVA.AddOn.Common.Controllers
{
    public class WarehouseController : SAPObjectBaseController
    {
        public WarehouseController()
            : base("OWHS")
        { }
    }
}
