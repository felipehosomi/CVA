﻿using CVA.View.Apetit.Cardapio.Helpers;
using SAPbouiCOM;
using System;

namespace CVA.View.Apetit.Cardapio.View
{
    public class TipoProteinaForm : BaseForm
    {
        public TipoProteinaForm()
        {
            Type = "CARDTPPT";
            TableName = "CVA_TIPOPROTEINA";
            MenuItem = Type;
            FilePath = TableName;
            //MatrixItens = "mtxGrps";
            //ChildName = "CVA_LIN_GRPSERVICOS";
            //IdToEvaluateGridEmpty = "U_CVA_ID_SERVICO";

            //ConfigureNavigationProperties("edtCode", false, true, false, false, false, false);
        }

        public override void Application_RightClickEvent(SAPbouiCOM.ContextMenuInfo eventInfo, out bool bubbleEvent)
        {
            var ret = true;
            bubbleEvent = ret;
        }

        public override void CreateUserFields()
        {
            var userFields = new UserFields();
            UserTables.CreateIfNotExist(TableName, "[CVA] Tipos de Proteína", SAPbobsCOM.BoUTBTableType.bott_NoObject);
        }

        internal override void LoadDefault(Form oForm)
        {
        }

        internal override void MenuEvent(Application Application, ref MenuEvent pVal, out bool bubbleEvent)
        {
            var ret = true;
            var openMenu = OpenMenu(MenuItem, FilePath, pVal);

            bubbleEvent = ret;
        }

        internal override void ItemEvent(Application Application, string FormUID, ref ItemEvent pVal, out bool bubbleEvent)
        {
            var ret = true;

            bubbleEvent = ret;
        }

        public override void SetFilters()
        {
            Filters.Add(MenuItem, BoEventTypes.et_MENU_CLICK);

            Filters.Add(Type, BoEventTypes.et_COMBO_SELECT);
            Filters.Add(Type, BoEventTypes.et_CHOOSE_FROM_LIST);
            Filters.Add(Type, BoEventTypes.et_PICKER_CLICKED);
            Filters.Add(Type, BoEventTypes.et_VALIDATE);
            Filters.Add(Type, BoEventTypes.et_LOST_FOCUS);
            Filters.Add(Type, BoEventTypes.et_FORM_DATA_ADD);
            Filters.Add(Type, BoEventTypes.et_FORM_DATA_UPDATE);
            Filters.Add(Type, BoEventTypes.et_FORM_DATA_LOAD);
            Filters.Add(Type, BoEventTypes.et_ITEM_PRESSED);
            Filters.Add(Type, BoEventTypes.et_MATRIX_LINK_PRESSED);
        }

        internal override void FormDataEvent(Application Application, ref BusinessObjectInfo BusinessObjectInfo, out bool bubbleEvent)
        {
            var ret = true;
            
            bubbleEvent = ret;
        }
        
        public override void SetMenus()
        {
            Helpers.Menus.Add("CVAPCONFIG", Type, "Tipos de Proteína", 1, BoMenuType.mt_STRING);
        }
    }
}