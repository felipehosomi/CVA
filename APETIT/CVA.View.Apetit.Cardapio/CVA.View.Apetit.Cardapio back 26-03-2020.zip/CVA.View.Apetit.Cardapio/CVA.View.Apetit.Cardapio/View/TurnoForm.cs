﻿using Addon.CVA.View.Apetit.Cardapio.Helpers;
using CVA.View.Apetit.Cardapio.Helpers;
using SAPbouiCOM;
using System;

namespace CVA.View.Apetit.Cardapio.View
{
    public class IncidenciaDeProteinaForm : BaseForm
    {
        //Campos da tabela
        public const string TB_Contrato = "CVA_ID_CONTRATO";
        public const string TB_TpProteina = "CVA_TIPO_PROTEINA";
        public const string TB_Gramatura = "CVA_GRAMATURA";
        public const string TB_Incidencia = "CVA_INCIDENCIA";

        public IncidenciaDeProteinaForm()
        {
            Type = "CARDINCP";
            TableName = "CVA_TABGRAMATURA";
            MenuItem = Type;
            FilePath = TableName;
            TITLE = "[CVA] Inc. Prot. Gramatura";
            //MatrixItens = "mtxGrps";
            //ChildName = "CVA_LIN_GRPSERVICOS";
            //IdToEvaluateGridEmpty = "U_CVA_ID_SERVICO";

            //ConfigureNavigationProperties("edtCode", false, true, false, false, false, false);
            ConfigureChooseFromListForNonObjectTable("OOAT", "1250010024", "7", "Number", "3", $"U_{TB_Contrato}", "1250000025");
        }

        public override void Application_RightClickEvent(SAPbouiCOM.ContextMenuInfo eventInfo, out bool bubbleEvent)
        {
            var ret = true;
            bubbleEvent = ret;
        }

        public override void CreateUserFields()
        {
            var userFields = new UserFields();

            UserTables.CreateIfNotExist(TableName, TITLE, SAPbobsCOM.BoUTBTableType.bott_NoObject);
            userFields.CreateIfNotExist("@" + TableName, TB_Contrato, "ID Contrato", 100, SAPbobsCOM.BoFieldTypes.db_Alpha, SAPbobsCOM.BoFldSubTypes.st_None, SAPbobsCOM.BoYesNoEnum.tYES);
            userFields.CreateIfNotExist("@" + TableName, TB_TpProteina, "Tipo de Proteína", 100, SAPbobsCOM.BoFieldTypes.db_Alpha, SAPbobsCOM.BoFldSubTypes.st_None, SAPbobsCOM.BoYesNoEnum.tYES);
            userFields.CreateIfNotExist("@" + TableName, TB_Gramatura, "Gramatura", 5, SAPbobsCOM.BoFieldTypes.db_Numeric, SAPbobsCOM.BoFldSubTypes.st_Measurement, SAPbobsCOM.BoYesNoEnum.tYES);
            userFields.CreateIfNotExist("@" + TableName, TB_Incidencia, "Incidência", 5, SAPbobsCOM.BoFieldTypes.db_Numeric, SAPbobsCOM.BoFldSubTypes.st_Quantity, SAPbobsCOM.BoYesNoEnum.tYES);
        }

        internal override void LoadDefault(Form oForm)
        {
            var f = oForm != null ? oForm : B1Connection.Instance.Application.Forms.ActiveForm;
            CreateChooseFromList(f);
        }

        internal override void MenuEvent(Application Application, ref MenuEvent pVal, out bool bubbleEvent)
        {
            var ret = true;
            var openMenu = OpenMenu(MenuItem, FilePath, pVal);

            bubbleEvent = ret;
        }

        internal override void ItemEvent(Application Application, string FormUID, ref ItemEvent pVal, out bool bubbleEvent)
        {
            var ret = true;

            bubbleEvent = ret;
        }

        public override void SetFilters()
        {
            Filters.Add(MenuItem, BoEventTypes.et_MENU_CLICK);
        }

        internal override void FormDataEvent(Application Application, ref BusinessObjectInfo BusinessObjectInfo, out bool bubbleEvent)
        {
            var ret = true;

            bubbleEvent = ret;
        }

        public override void SetMenus()
        {
            Helpers.Menus.Add("CVAPDADOSC", Type, "Incidência Prot. Gramatura", 5, BoMenuType.mt_STRING);
        }


        public void CreateChooseFromList(Form oForm)
        {
            int idCategoria = FormatedSearch.CreateCategory("Addon Apetit");
            string strSql = $@"SELECT * FROM {"@CVA_TIPOPROTEINA".Aspas()} ;";

            FormatedSearch.CreateFormattedSearches(strSql, "Busca Tipo Proteína Incid.", idCategoria, oForm.TypeEx, "3", $"U_{TB_TpProteina}");
        }
    }
}