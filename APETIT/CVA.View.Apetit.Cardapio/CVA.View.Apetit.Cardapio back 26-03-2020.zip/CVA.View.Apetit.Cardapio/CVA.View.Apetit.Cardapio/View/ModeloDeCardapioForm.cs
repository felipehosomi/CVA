﻿using Addon.CVA.View.Apetit.Cardapio.Helpers;
using CVA.View.Apetit.Cardapio.Helpers;
using SAPbouiCOM;
using System;

namespace CVA.View.Apetit.Cardapio.View
{
    public class ModeloDeCardapioForm : BaseForm
    {
        //Campos da tabela
        public const string TB_Descricao = "CVA_DESCRICAO";
        public const string CH_TipoPrato = "CVA_TIPO_PRATO";
        public const string CH_DesTipoPrato = "CVA_TIPO_PRATO_DES";

        public ModeloDeCardapioForm()
        {
            MatrixItens = "mtxGrps";
            Type = "CARDMDLC";
            TableName = "CVA_MCARDAPIO";
            ChildName = "CVA_LIN_MCARDAPIO";
            MenuItem = Type;
            FilePath = $"{AppDomain.CurrentDomain.BaseDirectory}\\Files\\{Type}.srf";
            IdToEvaluateGridEmpty = "it_CTpP";

            ConfigureNavigationProperties("edtCode", false, true, false, false, false, false);
        }

        public override void Application_RightClickEvent(SAPbouiCOM.ContextMenuInfo eventInfo, out bool bubbleEvent)
        {
            var ret = true;
            bubbleEvent = ret;
        }

        public override void CreateUserFields()
        {
            var userFields = new Helpers.UserFields();

            UserTables.CreateIfNotExist(TableName, "[CVA] Modelos de Cadápio", SAPbobsCOM.BoUTBTableType.bott_MasterData);
            userFields.CreateIfNotExist("@" + TableName, TB_Descricao, "Descrição", 254, SAPbobsCOM.BoFieldTypes.db_Alpha, SAPbobsCOM.BoFldSubTypes.st_None);

            UserTables.CreateIfNotExist(ChildName, "[CVA] ln Modelos de Cadápio", SAPbobsCOM.BoUTBTableType.bott_MasterDataLines);
            userFields.CreateIfNotExist("@" + ChildName, CH_TipoPrato, "Tipo de prato", 254, SAPbobsCOM.BoFieldTypes.db_Alpha, SAPbobsCOM.BoFldSubTypes.st_None, SAPbobsCOM.BoYesNoEnum.tYES);
            userFields.CreateIfNotExist("@" + ChildName, CH_DesTipoPrato, "Descr. Tipo de prato", 254, SAPbobsCOM.BoFieldTypes.db_Alpha, SAPbobsCOM.BoFldSubTypes.st_None, SAPbobsCOM.BoYesNoEnum.tYES);

            #region UDOs

            if (!UserObjects.Exists(Type))
            {
                userFields.CreateUserObject(Type, "[CVA] Modelos de Cadápio", TableName, SAPbobsCOM.BoUDOObjType.boud_MasterData);
                userFields.AddChildTableToUserObject(Type, ChildName);
            }

            #endregion
        }

        internal override void LoadDefault(Form oForm)
        {
            //oForm.Freeze(true);
            var f = oForm != null ? oForm : B1Connection.Instance.Application.Forms.ActiveForm;
            CreateChooseFromList(f);
            //oForm.Freeze(false);
        }

        internal override void MenuEvent(Application Application, ref MenuEvent pVal, out bool bubbleEvent)
        {
            var ret = true;
            var openMenu = OpenMenu(MenuItem, FilePath, pVal);

            if (!string.IsNullOrEmpty(openMenu))
            {
                ret = false;
                Application.SetStatusBarMessage(openMenu);
            }

            bubbleEvent = ret;
        }

        internal override void ItemEvent(Application Application, string FormUID, ref ItemEvent pVal, out bool bubbleEvent)
        {
            var ret = true;

            try
            {
                if (pVal.FormTypeEx.Equals(Type))
                {
                    if (pVal.BeforeAction)
                    {
                        #region Tipo Prato CHOOSE

                        if (pVal.ItemUID.Equals(MatrixItens) && pVal.ColUID.Equals("it_CTpP") && pVal.EventType.Equals(BoEventTypes.et_VALIDATE))
                        {
                            var oForm = Application.Forms.Item(pVal.FormUID);
                            var mtx = ((IMatrix)oForm.Items.Item(MatrixItens).Specific);
                            var it_CTpP = ((IEditText)mtx.Columns.Item("it_CTpP").Cells.Item(pVal.Row).Specific).Value;

                            if (!string.IsNullOrEmpty(it_CTpP))
                            {
                                SAPbobsCOM.Recordset rec = (SAPbobsCOM.Recordset)B1Connection.Instance.Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                                rec.DoQuery($@"
                                    SELECT 
	                                    * 
                                    FROM {"@CVA_TIPOPRATO".Aspas()}
                                    WHERE {"Code".Aspas()} = {it_CTpP}
                                    ");

                                if (rec.RecordCount > 0)
                                {
                                    var name = rec.Fields.Item("Name").Value.ToString();

                                    ((IEditText)mtx.Columns.Item("it_tpPrr").Cells.Item(pVal.Row).Specific).Value = name;

                                    //workaround para problema de não carregar demais linhas, colocar direto no dataSource
                                    oForm.DataSources.DBDataSources.Item("@" + ChildName).SetValue($"U_{CH_TipoPrato}", pVal.Row, it_CTpP);
                                    oForm.DataSources.DBDataSources.Item("@" + ChildName).SetValue($"U_{CH_DesTipoPrato}", pVal.Row, name);
                                }
                            }else if(pVal.Row < oForm.DataSources.DBDataSources.Item("@" + ChildName).Size)
                            {
                                oForm.DataSources.DBDataSources.Item("@" + ChildName).SetValue($"U_{CH_TipoPrato}", pVal.Row, "");
                                oForm.DataSources.DBDataSources.Item("@" + ChildName).SetValue($"U_{CH_DesTipoPrato}", pVal.Row, "");
                            }
                        }

                        #endregion
                    }
                }
            }
            catch (Exception ex)
            {
                Application.SetStatusBarMessage(ex.Message);
                ret = false;
            }

            bubbleEvent = ret;
        }

        public override void SetFilters()
        {
            Filters.Add(MenuItem, BoEventTypes.et_MENU_CLICK);
        }

        internal override void FormDataEvent(Application Application, ref BusinessObjectInfo BusinessObjectInfo, out bool bubbleEvent)
        {
            var ret = true;

            bubbleEvent = ret;
        }

        public override void SetMenus()
        {
            Helpers.Menus.Add("CVAPCONFIG", MenuItem, "Modelos de Cardápio", 3, BoMenuType.mt_STRING);
        }

        public void CreateChooseFromList(Form oForm)
        {
            int idCategoria = FormatedSearch.CreateCategory("Addon Apetit");
            string strSql = $@"SELECT * FROM {"@CVA_TIPOPRATO".Aspas()};";

            FormatedSearch.CreateFormattedSearches(strSql, "Busca Tipo Prato Modelo", idCategoria, Type, MatrixItens, "it_CTpP");
        }
    }
}