﻿using SAPbouiCOM.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CVA.View.Apetit.Cardapio
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {

            try
            {
                Application oApp = null;
                if (args.Length < 1)
                {
                    oApp = new Application();
                }
                else
                {
                    oApp = new Application(args[0]);
                }
                Menu MyMenu = new Menu();
                MyMenu.AddMenuItems();
                oApp.RegisterMenuEventHandler(MyMenu.SBO_Application_MenuEvent);
                Application.SBO_Application.AppEvent += new SAPbouiCOM._IApplicationEvents_AppEventEventHandler(SBO_Application_AppEvent);
                oApp.Run();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

            //try
            //{
            //    SAPbouiCOM.Framework.Application oApp = null;
            //    if (args.Length < 1)
            //    {
            //        oApp = new SAPbouiCOM.Framework.Application();
            //    }
            //    else
            //    {
            //        oApp = new SAPbouiCOM.Framework.Application(args[0]);
            //    }

            //    ////Menu MyMenu = new Menu();
            //    ////oApp.RegisterMenuEventHandler(MyMenu.SBO_Application_MenuEvent);
            //    ////SAPbouiCOM.Framework.Application.SBO_Application.AppEvent += new SAPbouiCOM._IApplicationEvents_AppEventEventHandler(SBO_Application_AppEvent);
            //    ////oApp.Run();

            //    //Application.EnableVisualStyles();
            //    //Application.SetCompatibleTextRenderingDefault(false);
            //    //new Controller.AppController();

            //    var app = new SBOApp();
            //    SAPbouiCOM.Framework.Application.SBO_Application.AppEvent += new SAPbouiCOM._IApplicationEvents_AppEventEventHandler(SBO_Application_AppEvent);
            //    oApp.Run();
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show(ex.Message);
            //}
        }

        static void SBO_Application_AppEvent(SAPbouiCOM.BoAppEventTypes EventType)
        {
            switch (EventType)
            {
                case SAPbouiCOM.BoAppEventTypes.aet_ShutDown:
                    //Exit Add-On
                    System.Windows.Forms.Application.Exit();
                    break;
                case SAPbouiCOM.BoAppEventTypes.aet_CompanyChanged:
                    break;
                case SAPbouiCOM.BoAppEventTypes.aet_FontChanged:
                    break;
                case SAPbouiCOM.BoAppEventTypes.aet_LanguageChanged:
                    break;
                case SAPbouiCOM.BoAppEventTypes.aet_ServerTerminition:
                    break;
                default:
                    break;
            }
        }

        /*
        public class SBOApp
        {
            #region
            public static SAPbouiCOM.SboGuiApi oSboGuiApi = null;
            public static SAPbouiCOM.Application SBO_Application = null;
            public static SAPbobsCOM.Company oCompany = null;



            public long lRetErr;
            public string sErrMsg;
            public int iErrCode;

            #endregion

            public SBOApp()
            {
                try
                {
                    SetApplicationUI();

                }
                catch
                {
                    throw;
                }
            }

            public void SetApplicationUI()
            {


                try
                {

                    oCompany = (SAPbobsCOM.Company)SAPbouiCOM.Framework.Application.SBO_Application.Company.GetDICompany();
                    string sCookie = string.Empty;
                    string sInfo = string.Empty;
                    sCookie = oCompany.GetContextCookie();
                    sInfo = SAPbouiCOM.Framework.Application.SBO_Application.Company.GetConnectionContext(sCookie);

                    iErrCode = oCompany.GetLastErrorCode();
                    if (iErrCode == 0)
                    {
                        SAPbouiCOM.Framework.Application.SBO_Application.StatusBar.SetText("Conectado a Empresa: " + oCompany.CompanyName, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                    }
                    else
                    {
                        oCompany.GetLastError(out iErrCode, out sErrMsg);
                        SAPbouiCOM.Framework.Application.SBO_Application.StatusBar.SetText("Erro: " + sErrMsg + " - CODE: " + Convert.ToString(iErrCode), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }

                    //}
                }
                catch (Exception ex)
                {
                    throw ex;
                }

            }

            public static string TranslateToHana(string sql)
            {

                return sql;

            }

        }
        
        */
    }
}
