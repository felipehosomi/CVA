 --EXEC SP_CVA_DIME_22 '0001' 
IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'SP_CVA_DIME_22')
	DROP PROCEDURE SP_CVA_DIME_22
GO
CREATE PROCEDURE SP_CVA_DIME_22
(
	@Code NVARCHAR(50)
)
AS
BEGIN
	CREATE TABLE #DIME
	(
		CFOP						NVARCHAR(MAX),
		Cidade						NVARCHAR(MAX),
		UF							NVARCHAR(2),
		ValorContabil				NUMERIC(19,6),
		BaseCalculo					NUMERIC(19,6),
		ImpostoCreditado			NUMERIC(19,6),
		Isentas						NUMERIC(19,6),
		Outras						NUMERIC(19,6),
		ImpostoRetido				NUMERIC(19,6),
		BaseCalculoImpostoRetido	NUMERIC(19,6)
	)
	
	INSERT INTO #DIME
	EXEC SP_CVA_DIME_ENTRADA @Code
	
	SELECT
		'22'									[Tipo],
		'01'									[Quadro],
		CFOP,
		SUM(DIME.ValorContabil)					[ValorContabil],
		SUM(DIME.BaseCalculo)					[BaseCalculo],
		SUM(DIME.ImpostoCreditado)				[ImpostoCreditado],
		SUM(DIME.Isentas)						[Isentas],
		SUM(DIME.Outras)						[Outras],
		SUM(DIME.BaseCalculoImpostoRetido)		[BaseCalculoImpostoRetido],
		SUM(DIME.ImpostoRetido)					[ImpostoRetido]
	FROM #DIME DIME
	WHERE ISNULL(DIME.CFOP, '') <> ''
	GROUP BY
		CFOP

	DROP TABLE #DIME
END
