--EXEC SP_CVA_DIME_23 '0001'
IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'SP_CVA_DIME_23')
	DROP PROCEDURE SP_CVA_DIME_23
GO
CREATE PROCEDURE SP_CVA_DIME_23
(
	@Code NVARCHAR(50)
)
AS
BEGIN
	CREATE TABLE #DIME
	(
		CardCode					NVARCHAR(MAX),
		CFOP						NVARCHAR(MAX),
		Cidade						NVARCHAR(MAX),
		UF							NVARCHAR(2),
		ValorContabil				NUMERIC(19,6),
		BaseCalculo					NUMERIC(19,6),
		ImpostoCreditado			NUMERIC(19,6),
		Isentas						NUMERIC(19,6),
		Outras						NUMERIC(19,6),
		ImpostoRetido				NUMERIC(19,6),
		BaseCalculoImpostoRetido	NUMERIC(19,6),
	)
	
	INSERT INTO #DIME
	EXEC SP_CVA_DIME_SAIDA @Code, 0
	
	SELECT
		'23'									[Tipo],
		'02'									[Quadro],
		CFOP,
		SUM(DIME.ValorContabil)					[ValorContabil],
		SUM(DIME.BaseCalculo)					[BaseCalculo],
		SUM(DIME.ImpostoCreditado)				[ImpostoCreditado],
		SUM(DIME.Isentas)						[Isentas],
		SUM(DIME.Outras)						[Outras],
		SUM(DIME.BaseCalculoImpostoRetido)		[BaseCalculoImpostoRetido],
		SUM(DIME.ImpostoRetido)					[ImpostoRetido]
	FROM #DIME DIME
	GROUP BY
		CFOP

	DROP TABLE #DIME
END
