IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'SP_CVA_DIME_ENTRADA')
	DROP PROCEDURE SP_CVA_DIME_ENTRADA
GO
CREATE PROCEDURE SP_CVA_DIME_ENTRADA
(
	@Code		NVARCHAR(50)
)
AS
BEGIN
	SELECT 
		PDN1.CFOPCode	CFOP,
		PDN12.CityS		Cidade,
		PDN12.StateS	UF,
		PDN1.LineTotal + PDN1.VatSum + ISNULL(PDN2.LineTotal, 0) ValorContabil,
		CASE WHEN OUSG.Usage LIKE 'E-Ativo%'
			THEN 0
			ELSE ICMS.BaseSum	
		END BaseCalculo,
		CASE WHEN (OCRD.U_h_simples_nacional = 1 AND OUSG.ID IN (76, 83)) OR OUSG.Usage LIKE 'E-Ativo%' OR OUSG.ID = 42 -- E-Desp Energia PR
			THEN 0
			ELSE ICMS.TaxSum		
		END ImpostoCreditado,
		CASE WHEN OUSG.Usage LIKE 'E-Ativo%'
			THEN 0
			ELSE ICMS.Isentas
		END Isentas,
		CASE WHEN OUSG.Usage LIKE 'E-Ativo%'
			THEN ICMS.BaseSum + ICMS.Outras
			ELSE ICMS.Outras
		END Outras,
		CASE WHEN OUSG.Usage LIKE 'E-Ativo%'
			THEN 0
			ELSE ICMS_ST.TaxSum		
		END ImpostoRetido,
		CASE WHEN OUSG.Usage LIKE 'E-Ativo%'
			THEN 0
			ELSE ICMS_ST.BaseSum	
		END BaseCalculoImpostoRetido
	FROM [@CVA_DIME] DIME WITH(NOLOCK)
		INNER JOIN OPDN WITH(NOLOCK)
			ON OPDN.BPLId = DIME.U_Filial OR DIME.U_Filial = 0
		INNER JOIN OCRD WITH(NOLOCK)
			ON OCRD.CardCode = OPDN.CardCode
		INNER JOIN PDN1 WITH(NOLOCK)
			ON PDN1.DocEntry = OPDN.DocEntry
		INNER JOIN OITM WITH(NOLOCK)
			ON OITM.ItemCode = PDN1.ItemCode
		INNER JOIN OUSG WITH(NOLOCK)
			ON OUSG.ID = PDN1.Usage
		INNER JOIN PDN12 WITH(NOLOCK)
			ON PDN12.DocEntry = OPDN.DocEntry
		LEFT JOIN PDN2 WITH(NOLOCK)
			ON PDN2.DocEntry = PDN1.DocEntry
			AND PDN2.LineNum = PDN1.LineNum
		LEFT JOIN (
					SELECT PDN4.DocEntry, PDN4.LineNum, SUM(PDN4.TaxSum) TaxSum, SUM(PDN4.BaseSum) BaseSum, SUM(U_ExcAmtS) Isentas, SUM(U_OthAmtS) Outras
					FROM PDN4 WITH(NOLOCK) 
						INNER JOIN OSTT WITH(NOLOCK) ON OSTT.AbsId = PDN4.StaType
						INNER JOIN ONFT WITH(NOLOCK) ON ONFT.AbsId = OSTT.NfTaxId AND ONFT.Code = 'ICMS'
					GROUP BY PDN4.DocEntry, PDN4.LineNum
				) ICMS
			ON ICMS.DocEntry = PDN1.DocEntry
			AND ICMS.LineNum = PDN1.LineNum
		LEFT JOIN (
					SELECT PDN4.DocEntry, PDN4.LineNum, SUM(PDN4.TaxSum) TaxSum, SUM(PDN4.BaseSum) BaseSum, SUM(U_ExcAmtS) Isentas, SUM(U_OthAmtS) Outras
					FROM PDN4 WITH(NOLOCK) 
						INNER JOIN OSTT WITH(NOLOCK) ON OSTT.AbsId = PDN4.StaType
						INNER JOIN ONFT WITH(NOLOCK) ON ONFT.AbsId = OSTT.NfTaxId AND ONFT.Code = 'ICMS-ST'
					GROUP BY PDN4.DocEntry, PDN4.LineNum
				) ICMS_ST
			ON ICMS_ST.DocEntry = PDN1.DocEntry
			AND ICMS_ST.LineNum = PDN1.LineNum
	WHERE DIME.Code = @Code
	AND OPDN.DocDate BETWEEN DIME.U_DtDe AND DIME.U_DtAte
	AND OPDN.CANCELED = 'N'
	AND OPDN.Model NOT IN (0, 28, 37, 3, 57)
	AND ISNULL(PDN1.TargetType, 0) <> 18

	UNION ALL

	SELECT 
		PCH1.CFOPCode	CFOP,
		PCH12.CityS		Cidade,
		PCH12.StateS	UF,
		PCH1.LineTotal + PCH1.VatSum + ISNULL(PCH2.LineTotal, 0) ValorContabil,
		CASE WHEN OUSG.Usage LIKE 'E-Ativo%'
			THEN 0
			ELSE ICMS.BaseSum	
		END BaseCalculo,
		CASE WHEN (OCRD.U_h_simples_nacional = 1 AND OUSG.ID IN (76, 83)) OR OUSG.Usage LIKE 'E-Ativo%' OR OUSG.ID = 42 -- E-Desp Energia PR
			THEN 0
			ELSE ICMS.TaxSum		
		END ImpostoCreditado,
		CASE WHEN OUSG.Usage LIKE 'E-Ativo%'
			THEN 0
			ELSE ICMS.Isentas
		END Isentas,
		CASE WHEN OUSG.Usage LIKE 'E-Ativo%'
			THEN ICMS.BaseSum + ICMS.Outras
			ELSE ICMS.Outras
		END Outras,
		CASE WHEN OUSG.Usage LIKE 'E-Ativo%'
			THEN 0
			ELSE ICMS_ST.TaxSum		
		END ImpostoRetido,
		CASE WHEN OUSG.Usage LIKE 'E-Ativo%'
			THEN 0
			ELSE ICMS_ST.BaseSum	
		END BaseCalculoImpostoRetido
	FROM [@CVA_DIME] DIME WITH(NOLOCK)
		INNER JOIN OPCH WITH(NOLOCK)
			ON OPCH.BPLId = DIME.U_Filial OR DIME.U_Filial = 0
		INNER JOIN OCRD WITH(NOLOCK)
			ON OCRD.CardCode = OPCH.CardCode
		INNER JOIN PCH1 WITH(NOLOCK)
			ON PCH1.DocEntry = OPCH.DocEntry
		INNER JOIN OITM WITH(NOLOCK)
			ON OITM.ItemCode = PCH1.ItemCode
		INNER JOIN OUSG WITH(NOLOCK)
			ON OUSG.ID = PCH1.Usage
		INNER JOIN PCH12 WITH(NOLOCK)
			ON PCH12.DocEntry = OPCH.DocEntry
		LEFT JOIN PCH2 WITH(NOLOCK)
			ON PCH2.DocEntry = PCH1.DocEntry
			AND PCH2.LineNum = PCH1.LineNum
		LEFT JOIN (
					SELECT PCH4.DocEntry, PCH4.LineNum, SUM(PCH4.TaxSum) TaxSum, SUM(PCH4.BaseSum) BaseSum, SUM(U_ExcAmtS) Isentas, SUM(U_OthAmtS) Outras
					FROM PCH4 WITH(NOLOCK) 
						INNER JOIN OSTT WITH(NOLOCK) ON OSTT.AbsId = PCH4.StaType
						INNER JOIN ONFT WITH(NOLOCK) ON ONFT.AbsId = OSTT.NfTaxId AND ONFT.Code = 'ICMS'
					GROUP BY PCH4.DocEntry, PCH4.LineNum
				) ICMS
			ON ICMS.DocEntry = PCH1.DocEntry
			AND ICMS.LineNum = PCH1.LineNum
		LEFT JOIN (
					SELECT PCH4.DocEntry, PCH4.LineNum, SUM(PCH4.TaxSum) TaxSum, SUM(PCH4.BaseSum) BaseSum, SUM(U_ExcAmtS) Isentas, SUM(U_OthAmtS) Outras
					FROM PCH4 WITH(NOLOCK) 
						INNER JOIN OSTT WITH(NOLOCK) ON OSTT.AbsId = PCH4.StaType
						INNER JOIN ONFT WITH(NOLOCK) ON ONFT.AbsId = OSTT.NfTaxId AND ONFT.Code = 'ICMS-ST'
					GROUP BY PCH4.DocEntry, PCH4.LineNum
				) ICMS_ST
			ON ICMS_ST.DocEntry = PCH1.DocEntry
			AND ICMS_ST.LineNum = PCH1.LineNum
	WHERE DIME.Code = @Code
	AND OPCH.DocDate BETWEEN DIME.U_DtDe AND DIME.U_DtAte
	AND OPCH.CANCELED = 'N'
	AND OPCH.Model NOT IN (0, 28, 37, 3, 57)

	UNION ALL

	SELECT 
		RIN1.CFOPCode	CFOP,
		RIN12.CityS		Cidade,
		RIN12.StateS	UF,
		RIN1.LineTotal + RIN1.VatSum + ISNULL(RIN2.LineTotal, 0) ValorContabil,
		CASE WHEN OUSG.Usage LIKE 'E-Ativo%'
			THEN 0
			ELSE ICMS.BaseSum	
		END BaseCalculo,
		CASE WHEN OUSG.Usage LIKE 'E-Ativo%' OR OUSG.ID = 42 -- E-Desp Energia PR
			THEN 0
			ELSE ICMS.TaxSum		
		END ImpostoCreditado,
		CASE WHEN OUSG.Usage LIKE 'E-Ativo%'
			THEN 0
			ELSE ICMS.Isentas
		END Isentas,
		CASE WHEN OUSG.Usage LIKE 'E-Ativo%'
			THEN ICMS.BaseSum + ICMS.Outras
			ELSE ICMS.Outras
		END Outras,
		CASE WHEN OUSG.Usage LIKE 'E-Ativo%'
			THEN 0
			ELSE ICMS_ST.TaxSum		
		END ImpostoRetido,
		CASE WHEN OUSG.Usage LIKE 'E-Ativo%'
			THEN 0
			ELSE ICMS_ST.BaseSum	
		END BaseCalculoImpostoRetido
	FROM [@CVA_DIME] DIME WITH(NOLOCK)
		INNER JOIN ORIN WITH(NOLOCK)
			ON ORIN.BPLId = DIME.U_Filial OR DIME.U_Filial = 0
		INNER JOIN RIN1 WITH(NOLOCK)
			ON RIN1.DocEntry = ORIN.DocEntry
		INNER JOIN OUSG WITH(NOLOCK)
			ON OUSG.ID = RIN1.Usage
		LEFT JOIN RIN2 WITH(NOLOCK)
			ON RIN2.DocEntry = RIN1.DocEntry
			AND RIN2.LineNum = RIN1.LineNum
		INNER JOIN RIN12 WITH(NOLOCK)
			ON RIN12.DocEntry = ORIN.DocEntry
		LEFT JOIN (
					SELECT RIN4.DocEntry, RIN4.LineNum, SUM(RIN4.TaxSum) TaxSum, SUM(RIN4.BaseSum) BaseSum, SUM(U_ExcAmtS) Isentas, SUM(U_OthAmtS) Outras
					FROM RIN4 WITH(NOLOCK) 
						INNER JOIN OSTT WITH(NOLOCK) ON OSTT.AbsId = RIN4.StaType
						INNER JOIN ONFT WITH(NOLOCK) ON ONFT.AbsId = OSTT.NfTaxId AND ONFT.Code = 'ICMS'
					GROUP BY RIN4.DocEntry, RIN4.LineNum
				) ICMS
			ON ICMS.DocEntry = RIN1.DocEntry
			AND ICMS.LineNum = RIN1.LineNum
		LEFT JOIN (
					SELECT RIN4.DocEntry, RIN4.LineNum, SUM(RIN4.TaxSum) TaxSum, SUM(RIN4.BaseSum) BaseSum, SUM(U_ExcAmtS) Isentas, SUM(U_OthAmtS) Outras
					FROM RIN4 WITH(NOLOCK) 
						INNER JOIN OSTT WITH(NOLOCK) ON OSTT.AbsId = RIN4.StaType
						INNER JOIN ONFT WITH(NOLOCK) ON ONFT.AbsId = OSTT.NfTaxId AND ONFT.Code = 'ICMS-ST'
					GROUP BY RIN4.DocEntry, RIN4.LineNum
				) ICMS_ST
			ON ICMS_ST.DocEntry = RIN1.DocEntry
			AND ICMS_ST.LineNum = RIN1.LineNum
	WHERE DIME.Code = @Code
	AND ORIN.DocDate BETWEEN DIME.U_DtDe AND DIME.U_DtAte
	AND ORIN.CANCELED = 'N'
	AND ORIN.Model NOT IN (0, 28, 37, 3, 57)
END
