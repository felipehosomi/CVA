﻿namespace CVA.Web.Hybel.Producao.Models
{
    public class ItemModel
    {
        public string CodigoProduto { get; set; }
        public int Quantidade { get; set; }
    }
}