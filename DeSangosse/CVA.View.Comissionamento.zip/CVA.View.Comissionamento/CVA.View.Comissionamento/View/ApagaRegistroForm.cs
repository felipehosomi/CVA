﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CVA.View.Comissionamento.View
{
    public class ApagaRegistroForm
    {
        public const string Type = "CVADEL";

        public static string FilePath = $"{AppDomain.CurrentDomain.BaseDirectory}\\Files\\apagaregistro.srf";

    }
}
