﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CVA.AddOn.Common.Models
{
    public class ModelBase
    {
        public string TableName { get; set; }
    }
}
